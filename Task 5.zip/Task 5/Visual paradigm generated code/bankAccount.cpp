#include "bankAccount.h"

int bankAccount::get_accountID() {
	// TODO - implement bankAccount::get_accountID
	throw "Not yet implemented";
}

void bankAccount::set_accountID(int accountID) {
	// TODO - implement bankAccount::set_accountID
	throw "Not yet implemented";
}

float bankAccount::get_balance() {
	// TODO - implement bankAccount::get_balance
	throw "Not yet implemented";
}

void bankAccount::set_balance(float balance) {
	// TODO - implement bankAccount::set_balance
	throw "Not yet implemented";
}

void bankAccount::deposit(int float_amount) {
	// TODO - implement bankAccount::deposit
	throw "Not yet implemented";
}

void bankAccount::withdraw(int float_amount) {
	// TODO - implement bankAccount::withdraw
	throw "Not yet implemented";
}

void bankAccount::display() {
	// TODO - implement bankAccount::display
	throw "Not yet implemented";
}
