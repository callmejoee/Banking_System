#include "client.h"

string client::get_name() {
	// TODO - implement client::get_name
	throw "Not yet implemented";
}

void client::set_name(int name) {
	// TODO - implement client::set_name
	throw "Not yet implemented";
}

string client::get_address() {
	// TODO - implement client::get_address
	throw "Not yet implemented";
}

void client::set_address(int address) {
	// TODO - implement client::set_address
	throw "Not yet implemented";
}

string client::get_phone() {
	// TODO - implement client::get_phone
	throw "Not yet implemented";
}

void client::set_phone(int phone) {
	// TODO - implement client::set_phone
	throw "Not yet implemented";
}

bool client::get_saving_flag() {
	// TODO - implement client::get_saving_flag
	throw "Not yet implemented";
}
