#include <iostream>
#include "BankingSystem.h"

using namespace std;

int main() {
    Bank_Application bank;
    bank.displayMenu();

    return 0;
}
